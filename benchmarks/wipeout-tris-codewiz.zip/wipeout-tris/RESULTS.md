# Validation, 2026-09-29

- Original `render_push_tris` body matches the local game source verbatim;
  all three extracted game headers also match. Body SHA256 is recorded in
  `source.sha256`.
- Native host `-O2`: all three texture modes passed, 2048 validated triangles
  per mode. UBSan build also passed with no diagnostics.
- Amiga `pr51` and `smallcopy`, default O2 flags: all three modes passed in
  vamos, exit code 0. Same result for `smallcopy-game` with
  `-O3 -fbbb=+ -ffast-math -mlra`.
- All three Amiga builds contain an identical GCC6 driver object (checked
  byte-for-byte) and use the same GCC6 runtime/linker driver.
- Kernel assembly: `pr51` contains one `jsr _memcpy`; `smallcopy` contains no
  memcpy call and copies the 96-byte triangle with inline longword moves.
- Additional host `-O3 -ffast-math` exploration failed the exact UV check:
  x86 assembly uses `rcpps`, and approximate reciprocals produce small bitwise
  differences. The oracle remains strict rather than hiding those differences.
  Default host builds and the tested m68k fast-math build pass.

Compilers used:

```text
fixed driver/runtime: /opt/amiga/bin/m68k-amigaos-gcc
pr51 kernel:          /opt/amiga16-pr51/bin/m68k-amigaos-gcc
smallcopy kernel:     /opt/amiga16-copy/bin/m68k-amigaos-gcc
```

Versions, options and source/object/executable hashes are in each variant's
`manifest.txt`; emulator output is in `validate.log`. Reproduce target checks
with your vamos installation:

```sh
vamos -C 68040 -H disable -m 16384 -s 128 --max-cycles 100000000 \
  -B out/pr51/trisbench 1
```

These are 68060-targeted binaries executed in the available 68040 emulator,
not tests on real 68060 hardware. Runs use one timing pass solely as a smoke
test; timer granularity is too coarse for performance conclusions. No new
speedup percentage is claimed, and Bebbo's competing patch was not built.
