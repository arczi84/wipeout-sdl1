#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if (( $# < 2 )); then
    echo 'Usage: bash build.sh LABEL KERNEL_CC [extra kernel flags...]' >&2
    echo 'Set DRIVER_CC once for all variants; TARGET_FLAGS may be empty for host builds.' >&2
    exit 2
fi
label=$1
kernel_cc=$2
shift 2
[[ $label =~ ^[A-Za-z0-9_-]+$ ]] || { echo 'Invalid label' >&2; exit 2; }
driver_cc=${DRIVER_CC:-m68k-amigaos-gcc}
read -r -a target_flags <<< "${TARGET_FLAGS--m68060 -mhard-float -noixemul}"
read -r -a kernel_flags <<< "${KERNEL_FLAGS--O2 -fomit-frame-pointer -fno-strict-aliasing -fcommon}"
out="out/$label"
mkdir -p "$out"
# Separate translation units, fixed driver/runtime, no LTO. Only the kernel
# compiler and its optimization flags should change between comparisons.
# Amiga HUNK objects embed their output name: keep it fixed so byte hashes
# also match, then preserve a copy next to each variant. Run builds serially.
"$driver_cc" -std=gnu99 -O2 "${target_flags[@]}" -fno-lto -c driver.c -o out/driver.o
cp out/driver.o "$out/driver.o"
"$kernel_cc" -std=gnu99 "${target_flags[@]}" "${kernel_flags[@]}" "$@" -fno-lto -c kernel.c -o "$out/kernel.o"
"$kernel_cc" -std=gnu99 "${target_flags[@]}" "${kernel_flags[@]}" "$@" -fno-lto -S -fverbose-asm kernel.c -o "$out/kernel.s"
"$driver_cc" "${target_flags[@]}" -fno-lto "$out/driver.o" "$out/kernel.o" -lm -o "$out/trisbench"
{
    printf 'Driver/link compiler: %s\n' "$driver_cc"
    "$driver_cc" --version
    printf 'Kernel compiler: %s\n' "$kernel_cc"
    "$kernel_cc" --version
    printf 'Target flags: %s\n' "${target_flags[*]}"
    printf 'Kernel flags: %s %s -fno-lto\n' "${kernel_flags[*]}" "$*"
    printf 'Driver flags: -std=gnu99 -O2 -fno-lto\n'
    sha256sum kernel.c driver.c bench.h types.h utils.h render_gl_legacy_types.h
    sha256sum "$out/driver.o" "$out/kernel.o" "$out/trisbench"
} > "$out/manifest.txt"
echo "Built $out/trisbench (assembly and manifest beside it)"
