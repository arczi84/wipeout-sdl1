#include "bench.h"
#include <string.h>
#include <sys/time.h>

#define N 1024
static tris_t input[N], expected[N];
static uint16_t tex[N];
static uint32_t consumed;
static int validating;

/* In a separate translation unit, without LTO: kernel stores stay observable.
 * During timing this callback counts triangles only, excluding checksum work. */
void bench_consume(const tris_t *tris, uint32_t count) {
    if (validating) {
        if (!count || count > 16 || consumed + count > 2 * N) {
            puts("FAIL flush bounds");
            exit(1);
        }
        for (uint32_t i = 0; i < count; ++i) {
            if (memcmp(&tris[i], &expected[(consumed + i) % N], sizeof(tris_t))) {
                printf("FAIL triangle %lu\n", (unsigned long)(consumed + i));
                const unsigned char *got = (const unsigned char *)&tris[i];
                const unsigned char *want = (const unsigned char *)&expected[(consumed + i) % N];
                for (unsigned b = 0; b < sizeof(tris_t); ++b)
                    if (got[b] != want[b])
                        printf("  byte %u: got %02x expected %02x\n", b, got[b], want[b]);
                exit(1);
            }
        }
    }
    consumed += count;
}

static double now(void) {
    struct timeval tv;
    if (gettimeofday(&tv, NULL)) { puts("timer failed"); exit(1); }
    return (double)tv.tv_sec + (double)tv.tv_usec * 0.000001;
}

static void prepare(unsigned texture_run) {
    memset(input, 0, sizeof(input));
    for (unsigned i = 0; i < N; ++i) {
        unsigned t = (i / texture_run) % 8;
        tex[i] = t;
        for (unsigned j = 0; j < 3; ++j) {
            vertex_t *v = &input[i].vertices[j];
            v->pos = (vec3_t){(float)i, (float)j, (float)(i + j)};
            v->uv = (vec2_t){(float)((i * 7 + j) % 256), (float)((i + j * 13) % 256)};
            v->color = (rgba_t){i % 256, (i + j * 31) % 256, (i * 3 + j) % 256,
                               i % 7 ? 255 : 0};
        }
        expected[i] = input[i];
        for (unsigned j = 0; j < 3; ++j) {
            vertex_t *v = &expected[i].vertices[j];
            /* Power-of-two values make reference results exact, including
             * under fast-math. This checks ABI/layout/copying as well as math. */
            v->uv.x *= 1.0f / (float)(32 << (t % 3));
            v->uv.y *= 0.5f / (float)(32 << ((t + 1) % 3));
            if (v->color.a) {
                v->color.r = v->color.r > 127 ? 255 : v->color.r * 2;
                v->color.g = v->color.g > 127 ? 255 : v->color.g * 2;
                v->color.b = v->color.b > 127 ? 255 : v->color.b * 2;
            }
        }
    }
}

static void run(unsigned passes) {
    consumed = 0;
    bench_reset();
    for (unsigned p = 0; p < passes; ++p)
        for (unsigned i = 0; i < N; ++i)
            render_push_tris(input[i], tex[i]);
    bench_finish();
    if (consumed != passes * N) { puts("FAIL count"); exit(1); }
}

int main(int argc, char **argv) {
    unsigned passes = 1000;
    if (argc > 2) { puts("usage: trisbench [passes: 1..1000000]"); return 1; }
    if (argc > 1) {
        char *end;
        unsigned long n = strtoul(argv[1], &end, 10);
        if (!*argv[1] || *end || n < 1 || n > 1000000) {
            puts("usage: trisbench [passes: 1..1000000, default 1000]");
            return 1;
        }
        passes = (unsigned)n;
    }
    printf("trisbench: vertex=%lu tris=%lu, %u passes; lower time is better\n",
           (unsigned long)sizeof(vertex_t), (unsigned long)sizeof(tris_t), passes);
    const unsigned runs[] = {1024, 8, 1};
    for (unsigned mode = 0; mode < 3; ++mode) {
        prepare(runs[mode]);
        validating = 1;
        run(2);
        validating = 0;
        run(2);
        printf("texture run %u, validation OK\n", runs[mode]);
        for (unsigned trial = 0; trial < 3; ++trial) {
            double start = now();
            run(passes);
            double elapsed = now() - start;
            if (elapsed <= 0) { puts("Increase passes (timer resolution)"); continue; }
            printf("  trial %u: %.6f s, %.1f ns/triangle\n", trial + 1,
                   elapsed, elapsed * 1e9 / ((double)passes * N));
        }
    }
    return 0;
}
