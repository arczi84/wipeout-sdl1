# Wipeout triangle submission benchmark

Standalone extraction of `render_push_tris` from arczi84's Wipeout port.
This is the workload behind AmigaPorts/gcc PR #52, merged as
`8145624a0a118bfeb837947513772be01217b3a3`, which codewiz referenced in
https://github.com/AmigaPorts/m68k-amigaos-gcc/issues/89#issuecomment-5884077405.
It is **Wipeout**, not the separate Jazz2 hard-float correctness reproducer.

The original function transforms triangle UVs, doubles/clamps RGB values,
switches texture batches, and assigns a **96-byte triangle** to a staging
buffer. This final assignment is the small-copy optimization of interest.
The by-value triangle argument also exercises compiler-generated copies in
the caller; using an identical driver object holds that cost constant.

No game assets, SDL, MiniGL, GPU or Amiga headers are required. C99 with GNU
extensions and a C runtime are sufficient. The kernel is in `kernel.c`;
`driver.c` supplies deterministic inputs, validation and timing.

## Build and run

Build every candidate with the same driver compiler/runtime, CPU and flags:

```sh
export DRIVER_CC=/path/to/fixed-sdk/bin/m68k-amigaos-gcc
bash build.sh baseline /path/to/baseline/bin/m68k-amigaos-gcc
bash build.sh smallcopy /path/to/smallcopy/bin/m68k-amigaos-gcc
bash build.sh bebbo /path/to/bebbo/bin/m68k-amigaos-gcc
```

Defaults: `-O2 -fomit-frame-pointer -fno-strict-aliasing -fcommon`,
`-m68060 -mhard-float -noixemul`, without LTO. Set `TARGET_FLAGS` for another
CPU/runtime. Additional arguments after the compiler apply only to the kernel
(e.g. `-mlra`). Set `KERNEL_FLAGS` to replace the optimization flags.

To reproduce the historical game optimization settings, use the following
for **every** candidate (where supported):

```sh
export KERNEL_FLAGS='-O3 -fbbb=+ -ffast-math -fomit-frame-pointer -fno-strict-aliasing -fcommon -mlra'
```

Each `out/LABEL/` contains an Amiga executable named `trisbench`, kernel
assembly and a manifest recording versions, flags and hashes. Confirm that
`driver.o` hashes match across variants. Keep the same runtime for all links.

On Amiga, from the directory containing each executable:

```text
trisbench 10000
```

The argument is passes (default 1000); each pass submits 1024 triangles.
Three modes switch texture every 1024, 8 or 1 triangles. Each mode validates
2048 output triangles byte-for-byte against a scalar reference, warms up, then
reports three timing trials in seconds and ns/triangle. Validation failures
exit nonzero. Use longer runs if trials are short; aim for at least one second.
Interleave candidate executions and compare medians on the same machine or
emulator configuration. The wall-clock timer is `gettimeofday`; JIT, host
load and temperature affect emulator timings.

For an isolated patch comparison, use compiler builds from the same base
with only the competing copy policy changed. Comparisons across installed SDK
versions are smoke tests, not evidence of a single patch's speed effect.

## Host correctness check

```sh
DRIVER_CC=cc TARGET_FLAGS='' bash build.sh host cc
./out/host/trisbench 10
```

Host timings do not measure m68k performance. Layout checks require 32-byte
vertices and 96-byte triangles at compile time. Input values give exact binary
UV reference values. The tested m68k fast-math build also matches exactly.
Some host fast-math builds use approximate reciprocal instructions and can
fail this intentionally strict byte comparison: use the default host flags.

## Integration in another benchmark suite

Compile `kernel.c` separately without LTO. The API is in `bench.h`:
`bench_reset`, `render_push_tris` and `bench_finish`; the harness must provide
`bench_consume`. `driver.c` demonstrates texture indices 0..7, the input
generator, independent expected results and the three batching patterns.
Keep consumption opaque to the kernel so buffer writes remain observable.
During timing the callback counts triangles; validation is outside timing.

The benchmark includes arithmetic, branching, by-value argument passing and
flush overhead. It is not a pure memcpy test or an FPS predictor. Inputs are
synthetic, not a captured game trace; this function was not established as
the game's largest frame-time contributor. GPU flushing is replaced, which
can change compiler decisions versus the full translation unit.

## Provenance

Recovered from the standalone snapshot created 2026-09-20 at
`/mnt/d/dev/wipeout/trisbench`. Function and three game headers were checked
against local `wipeout-minigl-git/src` on 2026-09-29. Repository:
https://github.com/arczi84/wipeout-sdl1 (local HEAD
`6ac273cbd3d97a2a1398ebedea7712634db732d0`; local files may differ from HEAD).
The function itself is copied verbatim; `source.sha256` records its hash.
The 16-triangle buffer, 8-byte buffer alignment, vertex layout and calling
convention are retained. GPU submission and texture setup are harness code.
This package adds configurable build commands, layout/flush checks and docs;
it does not alter the measured function. Original source attribution is
retained; no new license is assigned to the extracted game code.
