The workload behind my small-copy patch was actually Wipeout's
`render_push_tris`, rather than the separate Jazz2 FPU bug we investigated.
I've prepared a standalone benchmark of the original routine. It transforms
UVs/colors and copies a 96-byte triangle into a 16-triangle staging buffer.
It requires no game assets, SDL or MiniGL.

The package includes the unchanged kernel, a separate driver with an
independent correctness check, three texture-switch patterns, and configurable
build commands. Keeping the driver object and runtime fixed isolates changes
in kernel code generation. My baseline emits a memcpy call here; the
small-copy build emits inline moves. Both pass validation under vamos.

This should be useful for comparing the existing policy with Bebbo's patch
in BenchWork. The inputs are synthetic, and GPU submission is replaced by an
opaque callback, so this is a reduced game workload rather than a full-game
performance measurement.
